package controller

import (
	"net/http"
	"strconv"

	"github.com/labstack/echo/v4"
	"github.com/sraynitjsr/model"
	"github.com/sraynitjsr/service"
)

type UserController struct {
	userService service.UserService
}

func NewUserController(userService service.UserService) *UserController {
	return &UserController{userService}
}

func (c *UserController) CreateUser(ctx echo.Context) error {
	user := new(model.User)
	if err := ctx.Bind(user); err != nil {
		return err
	}
	if err := c.userService.CreateUser(user); err != nil {
		return err
	}
	return ctx.JSON(http.StatusCreated, user)
}

func (c *UserController) GetUser(ctx echo.Context) error {
	id, _ := strconv.Atoi(ctx.Param("id"))
	user, err := c.userService.GetUserByID(id)
	if err != nil {
		return echo.NewHTTPError(http.StatusNotFound, "User not found")
	}
	return ctx.JSON(http.StatusOK, user)
}

func (c *UserController) UpdateUser(ctx echo.Context) error {
	user := new(model.User)
	if err := ctx.Bind(user); err != nil {
		return err
	}
	if err := c.userService.UpdateUser(user); err != nil {
		return echo.NewHTTPError(http.StatusNotFound, "User not found")
	}
	return ctx.JSON(http.StatusOK, user)
}

func (c *UserController) DeleteUser(ctx echo.Context) error {
	id, _ := strconv.Atoi(ctx.Param("id"))
	if err := c.userService.DeleteUser(id); err != nil {
		return echo.NewHTTPError(http.StatusNotFound, "User not found")
	}
	return ctx.NoContent(http.StatusNoContent)
}

func (c *UserController) GetAllUsers(ctx echo.Context) error {
	users, _ := c.userService.GetAllUsers()
	return ctx.JSON(http.StatusOK, users)
}

func (c *UserController) Home(ctx echo.Context) error {
	return ctx.String(http.StatusOK, "Building REST API Using Echo Framework")
}
