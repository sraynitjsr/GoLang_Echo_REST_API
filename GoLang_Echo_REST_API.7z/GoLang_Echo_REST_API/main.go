package main

import (
	"github.com/labstack/echo/v4"
	"github.com/sraynitjsr/config"
	"github.com/sraynitjsr/controller"
	"github.com/sraynitjsr/dao"

	"github.com/sraynitjsr/service"
)

func main() {
	e := echo.New()

	userDao := &dao.UserDaoImpl{}
	userService := service.NewUserService(userDao)
	userController := controller.NewUserController(userService)

	e.GET("/", userController.Home)
	e.GET("/users", userController.GetAllUsers)
	e.POST("/users", userController.CreateUser)
	e.GET("/users/:id", userController.GetUser)
	e.PUT("/users/:id", userController.UpdateUser)
	e.DELETE("/users/:id", userController.DeleteUser)

	e.Logger.Fatal(e.Start(config.ServerPort))
}
