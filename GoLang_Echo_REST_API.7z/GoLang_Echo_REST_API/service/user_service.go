package service

import (
	"errors"

	"github.com/sraynitjsr/dao"
	"github.com/sraynitjsr/model"
)

type UserService interface {
	CreateUser(user *model.User) error
	GetUserByID(id int) (*model.User, error)
	UpdateUser(user *model.User) error
	DeleteUser(id int) error
	GetAllUsers() ([]*model.User, error)
}

type UserServiceImpl struct {
	userDao dao.UserDao
}

func NewUserService(userDao dao.UserDao) UserService {
	return &UserServiceImpl{userDao}
}

func (s *UserServiceImpl) CreateUser(user *model.User) error {
	s.userDao.CreateUser(user)
	return nil
}

func (s *UserServiceImpl) GetUserByID(id int) (*model.User, error) {
	user, ok := s.userDao.GetUserByID(id)
	if !ok {
		return nil, errors.New("user not found")
	}
	return user, nil
}

func (s *UserServiceImpl) UpdateUser(user *model.User) error {
	ok := s.userDao.UpdateUser(user)
	if !ok {
		return errors.New("user not found")
	}
	return nil
}

func (s *UserServiceImpl) DeleteUser(id int) error {
	ok := s.userDao.DeleteUser(id)
	if !ok {
		return errors.New("user not found")
	}
	return nil
}

func (s *UserServiceImpl) GetAllUsers() ([]*model.User, error) {
	return s.userDao.GetAllUsers(), nil
}
