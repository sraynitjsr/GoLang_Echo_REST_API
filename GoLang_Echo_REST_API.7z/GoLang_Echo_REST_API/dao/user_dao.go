package dao

import (
	"github.com/sraynitjsr/model"
	"github.com/sraynitjsr/repository"
)

type UserDao interface {
	CreateUser(user *model.User)
	GetUserByID(id int) (*model.User, bool)
	UpdateUser(user *model.User) bool
	DeleteUser(id int) bool
	GetAllUsers() []*model.User
}

type UserDaoImpl struct{}

func (u *UserDaoImpl) CreateUser(user *model.User) {
	repository.CreateUser(user)
}

func (u *UserDaoImpl) GetUserByID(id int) (*model.User, bool) {
	return repository.GetUserByID(id)
}

func (u *UserDaoImpl) UpdateUser(user *model.User) bool {
	return repository.UpdateUser(user)
}

func (u *UserDaoImpl) DeleteUser(id int) bool {
	return repository.DeleteUser(id)
}

func (u *UserDaoImpl) GetAllUsers() []*model.User {
	return repository.GetAllUsers()
}
