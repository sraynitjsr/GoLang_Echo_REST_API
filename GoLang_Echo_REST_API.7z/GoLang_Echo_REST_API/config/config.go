package config

const (
	ServerPort = ":8080"
)
