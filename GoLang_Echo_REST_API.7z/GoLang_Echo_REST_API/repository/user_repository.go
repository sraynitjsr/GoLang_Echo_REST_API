package repository

import "github.com/sraynitjsr/model"

var users = map[int]*model.User{}

func CreateUser(user *model.User) {
	user.ID = len(users) + 1
	users[user.ID] = user
}

func GetUserByID(id int) (*model.User, bool) {
	user, ok := users[id]
	return user, ok
}

func UpdateUser(user *model.User) bool {
	_, ok := users[user.ID]
	if !ok {
		return false
	}
	users[user.ID] = user
	return true
}

func DeleteUser(id int) bool {
	_, ok := users[id]
	if !ok {
		return false
	}
	delete(users, id)
	return true
}

func GetAllUsers() []*model.User {
	userList := []*model.User{}
	for _, user := range users {
		userList = append(userList, user)
	}
	return userList
}
